﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PCampeonato
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnExecutar_Click(object sender, EventArgs e)
        {
            int[,] matriz = new int[5, 3];

            int totalFeitos = 0, totalRecebidos = 0 ;

            for (int i = 0; i < 5; i++)
            {
                string input = Interaction.InputBox("Gols feitos: ", "Entrada de dados");

                //validacao()
                if (!int.TryParse(input, out matriz[i,0]))
                {
                    MessageBox.Show("Número invalido");
                    i--;
                }else
                {
                    input = Interaction.InputBox("Gols recebidos: ", "Entrada de dados");

                    //validacao()
                    if (!int.TryParse(input, out matriz[i, 1]))
                    {
                        MessageBox.Show("Número invalido");
                    }

                    matriz[i, 2] = matriz[i, 0] - matriz[i, 1];

                    totalFeitos += matriz[i, 0];
                    totalRecebidos += matriz[i, 1];

                    lstResultado.Items.Add("Time: " + (i+1) + " Gols feitos: " + matriz[i, 0] + " Gols recebidos: " +  matriz[i,1] + " Saldo de gols: " + matriz[i, 2]);
                }

            }

            lstResultado.Items.Add("--------------------------------------------");
            lstResultado.Items.Add("Total gols feitos: " + totalFeitos);
            lstResultado.Items.Add("Total gols recebidos: " + totalRecebidos);


        }

        private void LstResultado_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
