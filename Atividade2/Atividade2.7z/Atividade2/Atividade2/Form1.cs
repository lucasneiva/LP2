﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade2
{
   
    public partial class Form1 : Form
    {
        double numero1 = 0;
        double numero2 = 0;
        double resultado;
        public Form1()
        {
            InitializeComponent();
        }


        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Text = String.Empty;
            txtNum2.Text = String.Empty;
            txtRes.Text = String.Empty;
        }

        private void TxtNum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out numero1))
            {
                txtNum1.Focus();
                MessageBox.Show("Número 1 é inválido");
            }
            

        }

        private void TxtNum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum2.Text, out numero2))
            {
                txtNum2.Focus();
                MessageBox.Show("Número 2 é inválido");
            }
                
        }

        private void BtnSom_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNum1.Text, out numero1) && Double.TryParse(txtNum2.Text, out numero2))
            {
                resultado = numero1 + numero2;
                txtRes.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Números inválidos");
        }

        private void BtnSub_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNum1.Text, out numero1) && Double.TryParse(txtNum2.Text, out numero2))
            {
                resultado = numero1 - numero2;
                txtRes.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Números inválidos");
        }

        private void BtnMult_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNum1.Text, out numero1) && Double.TryParse(txtNum2.Text, out numero2))
            {
                resultado = numero1 * numero2;
                txtRes.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Números inválidos");
        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNum1.Text, out numero1) && Double.TryParse(txtNum2.Text, out numero2))
            {
                if (numero2 != 0)
                {
                    resultado = numero1 / numero2;
                    txtRes.Text = resultado.ToString();
                }
                else
                    txtNum2.Focus();
                    MessageBox.Show("Divisão por zero");
            }
            else
                MessageBox.Show("Números inválidos");
        }
    }
}
