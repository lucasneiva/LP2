﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade3
{
    public partial class Form1 : Form
    {
        double peso;
        double altura;
        double imc;

        string situacao;

        public Form1()
        {
            InitializeComponent();
        }



        private void BtnCalc_Click(object sender, EventArgs e)
        {
           
            if(altura <= 0)
            {
                MessageBox.Show("Altura inválida");
            }
            else
            {
                imc = peso / Math.Pow(altura, 2);

                imc = Math.Round(imc, 1);
                
                txtBoxRes.Text = imc.ToString();

                if (imc < 18.5)
                {
                    situacao = "Magreza";
                }
                else if(imc < 24.9)
                {
                    situacao = "Peso normal";
                }
                else if(imc < 29.9)
                {
                    situacao = "Sobrepeso";
                }
                else if(imc < 34.9)
                {
                    situacao = "Obesidade";
                }
                else if(imc < 39.9)
                {
                    situacao = "Obesidade grave";
                }

                MessageBox.Show(situacao);
            }
            
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            txtBoxAltura.Text = String.Empty;
            txtBoxPeso.Text = String.Empty;
        }

        private void LabelPeso_Click(object sender, EventArgs e)
        {

        }

        private void TxtBoxPeso_Validated(object sender, EventArgs e)
        {
            validarPeso();

        }
        private void TxtBoxAltura_Validated(object sender, EventArgs e)
        {
            validarAltura();
        }

        private void TxtBoxPeso_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char) 13)
            {
                validarPeso();
            }


        }

        private void TxtBoxAltura_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                validarAltura();
            }
        }

        void validarPeso()
        {
            if (!Double.TryParse(txtBoxPeso.Text, out peso))
            {
                MessageBox.Show("Peso Inválida");
                txtBoxPeso.Focus();
            }
        }

        void validarAltura()
        {
            if (!Double.TryParse(txtBoxAltura.Text, out altura))
            {
                MessageBox.Show("Altura Inválida");
                txtBoxAltura.Focus();
            }
        }

        private void BtnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }

    
}
