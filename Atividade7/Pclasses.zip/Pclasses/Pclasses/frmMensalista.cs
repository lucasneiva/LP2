﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            Mensalista objMen = new Mensalista();
            objMen.Matricula = Convert.ToInt32(txtMatricula.Text);
            objMen.NomeEmpregado = txtNome.Text;
            objMen.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objMen.SalarioMensal = Convert.ToDouble(txtSalMen.Text);

            if (rbtnSim.Checked)
            {
                objMen.HomeOffice = 'S';
            }
            else
                objMen.HomeOffice = 'N';

            MessageBox.Show("Mátricula: " + objMen.Matricula + "\n" +
                "Nome: " + objMen.NomeEmpregado + "\n" +
                "Data Entrada: " +
                objMen.DataEntradaEmpresa.ToShortDateString() + "\n" +
                "\n" + "Salário Bruto: " + objMen.SalarioBruto().ToString("N2") + "\n" +
                "Tempo Empresa (Dias): " + objMen.TempoTrabalho() + "\n" + objMen.VerificaHome());

        }
    }
}
